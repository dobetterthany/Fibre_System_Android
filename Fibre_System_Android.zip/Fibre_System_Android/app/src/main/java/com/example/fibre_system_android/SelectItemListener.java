package com.example.fibre_system_android;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public interface SelectItemListener {
    void onItemSelected(RecyclerViewItems item);

}
