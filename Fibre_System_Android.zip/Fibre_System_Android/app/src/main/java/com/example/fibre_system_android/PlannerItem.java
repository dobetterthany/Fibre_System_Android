package com.example.fibre_system_android;

import android.widget.ImageView;

public class PlannerItem {
    PlannerItem()
    {

    }
    ImageView icon;
    String name;
    int width = 0, height = 0;

}
